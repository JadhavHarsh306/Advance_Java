import React,{useState,useEffect} from 'react'
import {useParams} from 'react-router-dom';
import ProductService from '../service/ProductService';
export default function ViewProductDetails() {
    const [product,setproduct]=useState({})
    const params=useParams();
    useEffect(()=>{
       ProductService.getById(params.prodid)
       .then((result)=>{
        console.log(result);
        setproduct({...result.data})
       })
       .catch()
    },[])
    useEffect(()=>{
        ProductService.getById(params.prodid)
        .then((result)=>{
         console.log(result);
         setproduct({...result.data})
        })
        .catch()
     },[params.prodid])
  return (
    <div>ViewProductDetails {params.prodid}
       <div className="card" style={{"width": "18rem"}}>
  <div className="card-body">
    <h5 className="card-title">{product.pname}</h5>
    <h6 className="card-subtitle mb-2 text-muted">Id: {product.pid}</h6>
    <h6 className="card-subtitle mb-2 text-muted">name: {product.pname}</h6>
    <h6 className="card-subtitle mb-2 text-muted">Quantity: {product.qty}</h6>
    <h6 className="card-subtitle mb-2 text-muted">Price: {product.price}</h6>
    <h6 className="card-subtitle mb-2 text-muted">ExpDate: {product.expdate}</h6>
    <h6 className="card-subtitle mb-2 text-muted">Cid: {product.cid}</h6>
  </div>
</div>
    </div>
  )
}
