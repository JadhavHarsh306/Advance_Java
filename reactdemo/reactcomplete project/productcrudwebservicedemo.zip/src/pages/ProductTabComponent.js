import React,{useState,useEffect} from 'react'
import {Link,Outlet} from'react-router-dom'
import ProductService from '../service/ProductService'
export default function ProductTabComponent() {
    const [prodarr,setprodarr]=useState([])
    const [searcharr,setsearcharr]=useState([])
    const [searchtxt,setsearch]=useState("");
    //initialization useEffwct similar to componentDidMount
    useEffect(()=>{
        fetchdata();
    },[])
    //assign searcharr based on searchtxt
    useEffect(()=>{
        if(searchtxt===""){
            setsearcharr([...prodarr]);
        }else{
            let newarr=prodarr.filter(p=>p.pname.includes(searchtxt));
            setsearcharr(newarr);
        }
       
    },[searchtxt,prodarr])
    //to change search text on onchnage event
    const changesearchtxt=(event)=>{
        setsearch(event.target.value)
    }
    const fetchdata=()=>{
      //code for validation
      /*ProductService.validateUser(user)
      .then((result)=>{
        sessionStorage.token=result;
      })
      .catch()*/
        ProductService.getAllProducts()
        .then((response)=>{
            console.log(response);
            setprodarr([...response.data])
        })
        .catch((err)=>{
          console.log(err);
        })
       
    }
    const deletproduct=(pid)=>{
       ProductService.deleteById(pid)
       .then(()=>{
          fetchdata();
       })
       .catch((err)=>{
        console.log(err)
       });
       
    }
  return (
    <div>
        <Link to="/form">
        <button className="btn btn-info" type="button" name="Add new product" id="Add new product" value="Add new product">Add new product</button>
        </Link>
        Search : <input type="text" name="search" id="search"
        onChange={changesearchtxt}
        value={searchtxt}></input>
       <table className="table table-striped">
        <thead>
            <tr>
            <th scope="col">Product Id</th>
            <th scope="col">Name</th>
            <th scope="col">Quantity</th>
            <th scope="col">price</th>
            <th scope="col">Expiry date</th>
            <th scope="col">Category Id</th>
            <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    {searcharr.map(prod=> <tr key={prod.pid}>
      <td scope="row">{prod.pid}</td>
      <td>{prod.pname}</td>
      <td>{prod.qty}</td>
      <td>{prod.price}</td>
      <td>{prod.expdate}</td>
      <td>{prod.cid}</td>
      <td>
        <Link to={`/edit/${prod.pid}`} state={{editob:prod}}>
        <button className="btn btn-primary" type="button" name="edit" id="edit" value="edit">Edit</button>&nbsp;&nbsp;&nbsp;
        </Link>
        <button className="btn btn-danger" type="button" name="Delete" id="Delete" value="Delete" onClick={()=>{deletproduct(prod.pid)}}>Delete</button>&nbsp;&nbsp;&nbsp;
        <Link to={`/products/view/${prod.pid}`}>
        <button className="btn btn-success" type="button" name="View" id="View" value="View">View</button></Link>&nbsp;&nbsp;&nbsp;
      </td>
    </tr>)}
   
    
  </tbody>
</table>
<div>
  <Outlet></Outlet>
</div>
    </div>
  )
}
