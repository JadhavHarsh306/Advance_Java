import React,{useState,useEffect} from 'react'
import {useParams,useLocation,useNavigate} from 'react-router-dom'
import ProductService from '../service/ProductService';

export default function ProductEditForm() {
    //to retrieve params
    const params=useParams();
    //to get the data coming via state object
    const location=useLocation();
    const navigate=useNavigate();
    const [formdetails,setformdetails]=useState({pid:'',pname:'',qty:'',price:'',expdate:'',cid:''})
    const handlechange=(event)=>{
       let name=event.target.name;
       let value=event.target.value;
       setformdetails({...formdetails,[name]:value})
    } 
    const updateproduct=()=>{
        if( formdetails.pname==="" || formdetails.qty==="" || formdetails.price==="" || formdetails.expdate==="" || formdetails.cid===""){
           alert("pls fill all details")
          
        }else{
            let p={pid:parseInt(formdetails.pid),pname:formdetails.pname,qty:parseInt(formdetails.qty),price:parseFloat(formdetails.price),expdate:formdetails.expdate,cid:parseInt(formdetails.cid)}
            ProductService.updateproduct(p)
            .then((result)=>{
                console.log(result)
                //change the url to products
            navigate("/products")
            })
            .catch();
            
        }
        
    }
    useEffect(()=>{
        setformdetails({...location.state.editob})
    },[])
  return (
    <div>
        <form>
            <div className="form-group">
                <label htmlFor="pid">Product Id</label>
                <input type="text" className="form-control" id="pid" name='pid'
                onChange={handlechange}
                value={formdetails.pid}
                readOnly/>
                
            </div>
            <div className="form-group">
                <label htmlFor="pname">Product Name</label>
                <input type="text" className="form-control" id="pname" name='pname'
                onChange={handlechange}
                value={formdetails.pname}/>
            </div>
            <div className="form-group">
                <label htmlFor="qty">Quantity</label>
                <input type="text" className="form-control" id="qty" name='qty'
                onChange={handlechange}
                value={formdetails.qty}/>
            </div>
            <div className="form-group">
                <label htmlFor="price">Product Price</label>
                <input type="text" className="form-control" id="price" name='price'
                onChange={handlechange}
                value={formdetails.price}/>
            </div>
            <div className="form-group">
                <label htmlFor="expdate">Expiry Date</label>
                <input type="text" className="form-control" id="expdate" name='expdate'
                onChange={handlechange}
                value={formdetails.expdate}/>
            </div>
            <div className="form-group">
                <label htmlFor="cid">Category Id</label>
                <input type="text" className="form-control" id="cid" name='cid'
                onChange={handlechange}
                value={formdetails.cid}/>
            </div>
           
        <button type="button" className="btn btn-primary" onClick={updateproduct}>update product</button>
    </form>
    </div>
  )
}
