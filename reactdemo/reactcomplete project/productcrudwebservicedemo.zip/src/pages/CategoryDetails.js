import React from 'react'

export default function CategoryDetails(props) {
  return (
    <div>
        <div className="col-md-4">
        <div className="card" style={{"width": "18rem"}}>
            <div className="card-body">
                <h5 className="card-title">{props.data.cname}</h5>
                <h6 className="card-subtitle mb-2 text-muted">Id : {props.data.cid}</h6>
                <h6 className="card-subtitle mb-2 text-muted">Name : {props.data.cname}</h6>
                <h6 className="card-subtitle mb-2 text-muted">Description : {props.data.cdesc}</h6>
                
            </div>
</div>
        </div>
    </div>
  )
}
