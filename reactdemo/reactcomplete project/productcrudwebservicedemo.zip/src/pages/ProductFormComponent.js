import React,{useState} from 'react'
import ProductService from '../service/ProductService'
import {useNavigate} from 'react-router-dom'
export default function ProductFormComponent() {
    const [formdetails,setformdetails]=useState({pid:'',pname:'',qty:'',price:'',expdate:'',cid:''})
    const navigate=useNavigate();
    const [formerrors,setformerrors]=useState({pid:'',pname:'',qty:'',price:'',expdate:'',cid:''})
    const submitform=(event)=>{
        event.preventDefault(); // stop refresh page action of submit button
        if(formdetails.pid==="" || formdetails.pname==="" || formdetails.qty==="" || formdetails.price==="" || formdetails.expdate==="" || formdetails.cid===""){
           alert("pls fill all details")
           if(formdetails.pid==="" || formdetails.pid.trim().length>0){
            setformerrors({...formerrors,pid:"pls fill pid"})
           }
        }else{
            let p={pid:parseInt(formdetails.pid),pname:formdetails.pname,qty:parseInt(formdetails.qty),price:parseFloat(formdetails.price),expdate:formdetails.expdate,cid:parseInt(formdetails.cid)}
            ProductService.addnewproduct(p)
            .then((result)=>{
                console.log(result)
                navigate("/products")
            }).catch((err)=>{
                console.log(err)
            });
            //change the url to products
           
        }
        
        

    }
    const handlechange=(event)=>{
        let name=event.target.name;
        let value=event.target.value;
        setformdetails({...formdetails,[name]:value})

    }
    /*const changepid=(event)=>{
        setformdetails({...formdetails,pid:event.target.value})
    }
    const changepname=(event)=>{
        setformdetails({...formdetails,pname:event.target.pname})
    }*/
  return (
    <div>
        <form onSubmit={submitform}>
            <div className="form-group">
                <label htmlFor="pid">Product Id</label>
                <input type="text" className="form-control" id="pid" name='pid'
                onChange={handlechange}
                value={formdetails.pid}/>
                <p>{formerrors.pid}</p>
            </div>
            <div className="form-group">
                <label htmlFor="pname">Product Name</label>
                <input type="text" className="form-control" id="pname" name='pname'
                onChange={handlechange}
                value={formdetails.pname}/>
            </div>
            <div className="form-group">
                <label htmlFor="qty">Quantity</label>
                <input type="text" className="form-control" id="qty" name='qty'
                onChange={handlechange}
                value={formdetails.qty}/>
            </div>
            <div className="form-group">
                <label htmlFor="price">Product Price</label>
                <input type="text" className="form-control" id="price" name='price'
                onChange={handlechange}
                value={formdetails.price}/>
            </div>
            <div className="form-group">
                <label htmlFor="expdate">Expiry Date</label>
                <input type="text" className="form-control" id="expdate" name='expdate'
                onChange={handlechange}
                value={formdetails.expdate}/>
            </div>
            <div className="form-group">
                <label htmlFor="cid">Category Id</label>
                <input type="text" className="form-control" id="cid" name='cid'
                onChange={handlechange}
                value={formdetails.cid}/>
            </div>
           
  <button type="submit" className="btn btn-primary">Submit</button>
</form>
    </div>
  )
}
