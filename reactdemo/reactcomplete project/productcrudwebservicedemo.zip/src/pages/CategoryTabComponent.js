import React,{useState,useEffect} from 'react'
import CategoryService from '../service/CategoryService'
import CategoryDetails from './CategoryDetails'
export default function CategoryTabComponent() {
    const [categoryarr,setcategoryarr]=useState([])
    useEffect(()=>{
        CategoryService.getAllCategory()
        .then((result)=>{
          setcategoryarr([...result.data])
        })
        .catch(()=>{});
        
    },[])
  return (
    <div>
        <button className="btn btn-info" type="button" name="addc" id="addc" value="addc">Add new Category</button>
        <div className="container">
            <div className="row">
            {categoryarr.map(c=><CategoryDetails key={c.cid} data={c}></CategoryDetails>)}
        </div>
        </div>
       
    </div>
  )
}
