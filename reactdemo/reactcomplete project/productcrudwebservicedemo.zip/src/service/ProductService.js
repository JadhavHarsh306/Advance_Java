import axios from 'axios';
//let baseUrl="http://localhost:4002/"
var baseUrl="http://localhost:9090/SpringRestWebService/product/"; 

class ProductService{
    constructor(){
        /*this.prodarr=[{pid:12,pname:"chair",qty:4,price:4500,expdate:"2000-11-12",cid:1},
        {pid:13,pname:"table",qty:10,price:4000,expdate:"2001-11-12",cid:1},
        {pid:14,pname:"shelf",qty:5,price:3000,expdate:"2002-11-12",cid:1}
        ]*/
    }
    validateUser(user){
        return axios.post("/login",user,)
    } 
    getAllProducts(){
        //return this.prodarr;
        //get request
        return axios.get(baseUrl+"products")
    }
    getById(pid){
        return axios.get(baseUrl+"products/"+pid)
    }
    addnewproduct(p){
        let myheaders={'content-Type':'application/json'}//,'Atherization':"bearer"+sessionStorage.token}
        return axios.post(baseUrl+"products/"+p.pid,p,{headers:myheaders})
    }
    updateproduct(p){
        let myheaders={'content-Type':'application/json'}
        return axios.put(baseUrl+"products/"+p.pid,p,{headers:myheaders})
    }
    deleteById(pid){
        //let myheaders={'content-Type':'application/json'}
        return axios.delete(baseUrl+"products/"+pid)
    }

}

export default new ProductService();