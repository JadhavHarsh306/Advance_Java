import axios from 'axios';
let baseUrl="http://localhost:4002/" 
class Category{
    constructor(){
        this.category=[{cid:1,cname:'furniture',cdesc:'goodquality'},
        {cid:2,cname:'food',cdesc:'very tasty'} ,
        {cid:3,cname:'stationary',cdesc:'long lasting, duarble'},
        {cid:4,cname:'vehicle',cdesc:'2 wheelers'},{cid:5,cname:'technical',cdesc:'elligant'} 
        ]
    }
    getAllCategory(){
        return axios.get(baseUrl+"categories")
    }
}
export default new Category();