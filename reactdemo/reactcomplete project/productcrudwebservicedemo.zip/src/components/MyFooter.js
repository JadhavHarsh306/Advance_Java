import React from 'react'
import './MyHeader.css'
export default function MyFooter() {
    console.log("in footer component function")
  return (
    <div>
        <h4 className="myfooter">&copy; copyrights reseved</h4>
    </div>
  )
}
